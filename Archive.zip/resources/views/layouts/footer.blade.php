   <!-- footer content -->
   <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="{{ URL::asset('') }}plugins/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="{{ URL::asset('') }}plugins/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="{{ URL::asset('') }}plugins/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="{{ URL::asset('') }}plugins/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="{{ URL::asset('') }}plugins/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="{{ URL::asset('') }}plugins/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="{{ URL::asset('') }}plugins/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="{{ URL::asset('') }}plugins/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="{{ URL::asset('') }}plugins/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="{{ URL::asset('') }}plugins/vendors/Flot/jquery.flot.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/Flot/jquery.flot.time.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/Flot/jquery.flot.resize.js"></script>
     <!-- DataTable Theme Scripts -->
     <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
     <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
     <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
     <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.html5.min.js"></script>

    <!-- Flot plugins -->
    <script src="{{ URL::asset('') }}plugins/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="{{ URL::asset('') }}plugins/vendors/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="{{ URL::asset('') }}plugins/vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="{{ URL::asset('') }}plugins/vendors/moment/min/moment.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
   <!-- bootstrap-validate -->
    <script src="{{ URL::asset('') }}plugins/build/js/jquery.validate.js"></script> 
    <!-- Custom Theme Scripts -->
    <script src="{{ URL::asset('') }}plugins/build/js/custom.min.js"></script>
  
     <!-- <script src="{{ URL::asset('') }}plugins/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/jszip/dist/jszip.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="{{ URL::asset('') }}plugins/vendors/pdfmake/build/vfs_fonts.js"></script> -->

	@yield('js')
  </body>
</html>
